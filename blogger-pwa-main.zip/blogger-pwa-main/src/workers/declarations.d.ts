declare module '__STATIC_CONTENT_MANIFEST' {
  const assetsManifest: string | Record<string, string>;

  export default assetsManifest;
}
